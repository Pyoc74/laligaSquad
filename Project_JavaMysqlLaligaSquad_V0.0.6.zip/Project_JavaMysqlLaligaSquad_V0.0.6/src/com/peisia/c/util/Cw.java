package com.peisia.c.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Cw {
    public static void w(String s) {
        System.out.print(s);
    }

    public static void wn(String s) {
        System.out.println(s);
    }

    public static void wn() {
        System.out.println();
    }
}
