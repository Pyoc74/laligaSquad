package com.peisia.c.laligasquad.operations;

import java.util.HashMap;
import java.util.Map;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class MarketValueDistribution {
    public void execute() {
        Cw.wn("조회할 시장가치 범위를 선택해주세요(만 유로):");
        Cw.wn("1) 0 이상 ~ 100 미만");
        Cw.wn("2) 100 이상 ~ 1000 미만");
        Cw.wn("3) 1000 이상 ~ 3000 미만");
        Cw.wn("4) 3000 이상 ~ 6000 미만");
        Cw.wn("5) 6000 이상 ~ 10000 미만");
        Cw.wn("6) 10000 이상");

        String rangeOption = Ci.r("번호 입력: ");
        String rangeQuery = "";

        switch (rangeOption) {
            case "1":
                rangeQuery = "SELECT * FROM laliga_squad WHERE p_market_value >= 0 AND p_market_value < 100";
                break;
            case "2":
                rangeQuery = "SELECT * FROM laliga_squad WHERE p_market_value >= 100 AND p_market_value < 1000";
                break;
            case "3":
                rangeQuery = "SELECT * FROM laliga_squad WHERE p_market_value >= 1000 AND p_market_value < 3000";
                break;
            case "4":
                rangeQuery = "SELECT * FROM laliga_squad WHERE p_market_value >= 3000 AND p_market_value < 6000";
                break;
            case "5":
                rangeQuery = "SELECT * FROM laliga_squad WHERE p_market_value >= 6000 AND p_market_value < 10000";
                break;
            case "6":
                rangeQuery = "SELECT * FROM laliga_squad WHERE p_market_value >= 10000";
                break;
            default:
                System.out.println("잘못된 입력입니다. 다시 시도해주세요.");
                return;
        }

        try {
            Db.result = Db.st.executeQuery(rangeQuery);
            System.out.println("========== 선택된 시장가치 범위 선수 리스트 ==========");

            Map<String, Integer> teamCountMap = new HashMap<>();

            while (Db.result.next()) {
                String clubV = Db.result.getString("p_club");
                String backNoV = Db.result.getString("p_number");
                String nameV = Db.result.getString("p_name");
                String birthV = Db.result.getString("p_birth");
                String positionV = Db.result.getString("p_position");
                String marketValueV = Db.result.getString("p_market_value");
                System.out.println(clubV + " / " + backNoV + " / " + nameV + " / " + birthV + " / " + positionV + " / " + marketValueV + "만 유로");

                teamCountMap.put(clubV, teamCountMap.getOrDefault(clubV, 0) + 1);
            }

            System.out.println("========== 팀별 인원 수 ==========");
            for (Map.Entry<String, Integer> entry : teamCountMap.entrySet()) {
                System.out.println(entry.getKey() + ": " + entry.getValue() + "명");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
