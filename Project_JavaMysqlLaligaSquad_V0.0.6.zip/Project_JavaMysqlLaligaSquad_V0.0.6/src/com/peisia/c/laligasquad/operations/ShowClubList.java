package com.peisia.c.laligasquad.operations;

import java.util.HashSet;
import java.util.Set;

import com.peisia.c.util.Ci;
import com.peisia.c.util.Cw;
import com.peisia.c.util.Db;

public class ShowClubList {
	 public void execute() {
	        System.out.println("=============================");
	        System.out.println("========== 클럽 리스트 ========");
	        try {
	            Set<String> clubSet = new HashSet<>();
	            Db.result = Db.st.executeQuery("SELECT DISTINCT p_club FROM laliga_squad");
	            while (Db.result.next()) {
	                String club = Db.result.getString("p_club");
	                clubSet.add(club);
	            }

	            for (String club : clubSet) {
	                System.out.println("클럽: " + club);
	            }

	            String selectedClub = Ci.rl("확인할 클럽 이름을 입력해주세요: ");
	            String query = String.format("SELECT * FROM laliga_squad WHERE p_club = '%s'", selectedClub);
	            Db.result = Db.st.executeQuery(query);
	            Cw.wn("========== 선택된 클럽 선수 리스트 ==========");

	            while (Db.result.next()) {
	                String club = Db.result.getString("p_club");
	                String backNo = Db.result.getString("p_number");
	                String name = Db.result.getString("p_name");
	                String position = Db.result.getString("p_position");
	                System.out.println(club + " " + backNo + " " + name + " " + position);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
}
